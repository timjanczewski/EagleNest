﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Text;
using RouteCalculator.Domain.Entities;

namespace RouteCalculator.Web.Controllers
{
    public class HomeController : BaseController
    {
        public ActionResult Index()
        {
            List<Vehicle> vehicles = GetVehicles();
            List<string> Makes = new List<string>();
            foreach (Vehicle v in vehicles)
            {
                Makes.Add(v.Make + " | " + v.Model);
            }

            ViewData["MakesModels"] = new SelectList(Makes);
            List<Quote> Quotes = new List<Quote>();
            Quote q = new Quote();
            Quotes.Add(q);
            ViewBag.Quotes = Quotes;

            return View();
        }

        public ActionResult GetPrice(string zipcode1, string zipcode2, string vehicle)
        {
            string Make = string.Empty;
            string Model = string.Empty;

            char[] delimiterChars = { '|' };
            string[] makemodel = vehicle.Split(delimiterChars);
            Make = makemodel[0].ToString();
            Model = makemodel[1].ToString();
           
            var origin = _db.ZipcodePools.Where(x => x.ZipCode == zipcode1);
            var destination = _db.ZipcodePools.Where(x => x.ZipCode == zipcode2);

            ZipcodePool pool1 = origin.FirstOrDefault();
            ZipcodePool pool2 = destination.FirstOrDefault();
            
            var Area1 = _db.MajorAreas.Where(x => x.Pool1Name == pool1.PoolName);
            MajorArea ma1 = Area1.FirstOrDefault();

            var Area2 = _db.MajorAreas.Where(x => x.Pool1Name == pool2.PoolName);
            MajorArea ma2 = Area2.FirstOrDefault();

            var routes = _db.Routes.Where(y => y.Area1 == ma1.AreaName && y.Area2 == ma2.AreaName);
            Route baseprice = routes.FirstOrDefault();

            double multiplier = 1 + (GetVehicleMultiplier(Make, Model) * 0.01);
            double price = Convert.ToDouble(baseprice.Price) * multiplier;

            Quote q = new Quote();

            q.Vehicle = Make + " " + Model;
            q.Area1 = zipcode1;
            q.Area2 = zipcode2;
            q.Price = price;

            List<Vehicle> vehicles = GetVehicles();
            List<string> Makes = new List<string>();
            foreach (Vehicle v in vehicles)
            {
                Makes.Add(v.Make + " | " + v.Model);
            }

            ViewData["MakesModels"] = new SelectList(Makes);
            List<Quote> Quotes = new List<Quote>();
            Quotes.Add(q);
            ViewBag.Quotes = Quotes;

            return View("Index");
        }

        public List<Vehicle> GetVehicles()
        {

            var makes = _db.Vehicles;

            List<Vehicle> vehicles = new List<Vehicle>();
            vehicles = makes.ToList<Vehicle>();
                        
            
            return vehicles;
        }

        private double GetVehicleMultiplier(string make, string model)
        {
            double percent = 1;

            string vmake = make.Trim();
            string vmodel = model.Trim();

            var vehicle = _db.Vehicles.Where(x => x.Make == vmake && x.Model == vmodel);
            Vehicle v = vehicle.FirstOrDefault();

            string vClass = v.Category;

            var cat = _db.Categories.Where(c => c.Class == vClass);
            Category category = cat.FirstOrDefault();

            if (category.PricePercentIncrease > 0)
            { percent = Convert.ToDouble(category.PricePercentIncrease); }

            return percent;
        }
        
        
    }
}
